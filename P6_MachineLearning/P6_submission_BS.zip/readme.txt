Auxiliary functions in poi_id_helper.py
